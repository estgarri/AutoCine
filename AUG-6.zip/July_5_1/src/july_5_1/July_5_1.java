
package july_5_1;

import java.io.IOException;

public class July_5_1 
{
    public static void main(String[] args) throws IOException 
    {
   
    
    seguridad.security();
    
    
}
}
