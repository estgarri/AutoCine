
package semana10_c2_2022;


public class Semana10_C2_2022 {

    
    public static void main(String[] args)
    {
       Notas miregistro = new Notas();
       
       miregistro.Ingresar_Cantidad_Notas();
       miregistro.Ingresar_Notas();
       miregistro.Consultar_Notas();
       miregistro.Consultar_Nota_Especifica();
    }
    
}
