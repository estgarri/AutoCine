package autocine;

import javax.swing.*;
import java.awt.HeadlessException;


public class Menu
{
    public static boolean seguir = true;
    public static String[] opciones = { "","1. Nuevas Reservaciones", "2. Modificar Reservación", "3. Cancelar Reservación", "4. Consultas", "5. Reportes", "6. Salir"};
    public static int opcion = 0;
    public static String msg = ("1. Nuevas Reservaciones. \n" +
            "2. Modificar Reservación. \n" +
            "3. Cancelar Reservación. \n" +
            "4. Consultas. \n" +
            "5. Reportes.\n" +
            "6. Salir.");

    public void Menu()
    {
        seguir = true;
        while (seguir == true)
        {
            opcion = 0;

            try
            {
                opcion = Integer.parseInt(JOptionPane.showInputDialog("Sistema AutoCine: \n" +
                        "1. Digite '1' para reservaciones.\n" +
                        "2. Digite '2' para modificar reservación.\n" +
                        "3. Digite '3' para cancelar reservación.\n" +
                        "4. Digite '4' para consultar reservación existente.\n" +
                        "5. Digite '5' para imprimir reporte general de la ocupación del Autocine.\n" +
                        "6. Digite '6' para salir."));

            } catch (HeadlessException | NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Opción no válida, por favor intente de nuevo.");
            }
        }
    }

    public void MenuDropDown()
    {
        ImageIcon imagen = new ImageIcon("AutoCine.png");
        seguir = true;
        Disponible disponible = new Disponible();

        while (seguir == true)
        {
            String res = (String) JOptionPane.showInputDialog(null, msg, "Sistema AutoCine",
                    JOptionPane.PLAIN_MESSAGE, imagen, opciones, opciones[0]);
            switch (res) {
                case "1. Nuevas Reservaciones":
                    System.out.println("Nuevas Reservaciones");
                    disponible.stalls();
                    disponible.reservar();
                    break;
                case "2. Modificar Reservación":
                    System.out.println("Modificar Reservación");
                    disponible.modificar();
                    break;
                case "3. Cancelar Reservación":
                    System.out.println("Cancelar Reservación");
                    disponible.cancelar();
                    disponible.stalls();
                    System.out.println(disponible.cadena);
                    break;
                case "4. Consultas":
                    System.out.println("Consultas");
                    disponible.stalls();
                    System.out.println(disponible.cadena);
                    break;
                case "5. Reportes":
                    System.out.println("Reportes");
                    break;
                case "6. Salir":
                    System.out.println("Salir");
                    seguir = false;
                    break;
            }

        }

    }
}
