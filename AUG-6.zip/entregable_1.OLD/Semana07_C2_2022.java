
package semana07_c2_2022;


public class Semana07_C2_2022 {

    
    public static void main(String[] args) 
    {
       Registro registro= new Registro();
       
       //Matricula carrier = new Matricula();

       registro.SolicitarUsuario();
       registro.MostrarPersona();
      
       *carrier.Registrar_Matricula();
       //carrier.MostrarUsuario();

       //test.carrier();
      
       
    }
    
}
