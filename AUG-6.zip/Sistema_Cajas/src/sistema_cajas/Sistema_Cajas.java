/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema_cajas;

/**
 *
 * @author RCastroMendez
 */
public class Sistema_Cajas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Usuario conexion = new Usuario();
        
        conexion.Validar_Usuario();
    }
    
}
