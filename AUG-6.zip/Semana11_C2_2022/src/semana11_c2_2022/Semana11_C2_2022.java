/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana11_c2_2022;

/**
 *
 * @author RCastroMendez
 */
public class Semana11_C2_2022 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Registro_Estudiante miregistro = new Registro_Estudiante();
        
        miregistro.Registrar_Cantidad_Estudiantes();
        miregistro.Ingresar_Estudiantes();
        miregistro.Consultar_Registro();
    }
    
}
