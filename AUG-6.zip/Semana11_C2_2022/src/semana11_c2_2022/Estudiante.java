
package semana11_c2_2022;


public class Estudiante {
    
    public int Cedula;
    public String Nombre;
    public String Apellidos;
    public int Edad;
    
    public Estudiante(int cedula, String nombre, String apellidos, int edad)
    {
        this.Cedula = cedula;
        this.Nombre = nombre;
        this.Apellidos = apellidos;
        this.Edad = edad;
    }
    
}
