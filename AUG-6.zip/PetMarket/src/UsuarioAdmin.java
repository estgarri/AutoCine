
public class UsuarioAdmin {
    private static String UserAdmin = "Admin";
    private static String PassAdmin = "123";


    public String getPassAdmin()
    {
        return PassAdmin;
    }

    public String getUserAdmin()
    {
        return UserAdmin;
    }

    public void setPassAdmin(String Pass) { PassAdmin = Pass;}

    public void setUserAdmin(String User) { UserAdmin = User;}


}
