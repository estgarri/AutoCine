public enum Rol
{
    Vendedor,
    Gerente
}
