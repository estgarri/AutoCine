
package semana09_c2_2022;


public enum Estados {
    
    Activo,
    Inactivo,
    En_Revisión
    
}
