
package semana09_c2_2022;


public enum Rol {
    
   Administrador,
   Asistente,
   Cajero,
   Supervisor
    
}
