
package semana09_c2_2022;

import javax.swing.JOptionPane;


public class Semana09_C2_2022 {

   
    public static void main(String[] args) 
    {
        //Persona miclase = new Persona();
        /*
        miclase.Nombre = "Pablo";
        miclase.Apellidos = "Perez Molina";
        
        miclase.setCedula(123456789);
        miclase.setEdad(35);
        
        miclase.Estado = Estados.Activo;
        
        JOptionPane.showMessageDialog(null, "Los datos de la persona son: \n"+
                                            "Nombre: " + miclase.Nombre + "\n"+
                                            "Apellidos: " + miclase.Apellidos + "\n"+
                                            "Cédula: " + miclase.getCedula() + "\n"+
                                            "Edad: " + miclase.getEdad()+ "\n"+
                                            "Estado: " + miclase.Estado);*/
        
        Usuario miclase2 = new Usuario();
        
        miclase2.Registrar_Usuario();
                
        
        
        
    }
    
}
