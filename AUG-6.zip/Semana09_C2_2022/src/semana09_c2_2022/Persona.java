
package semana09_c2_2022;


public class Persona 
{
    public static String Nombre;
    public static String Apellidos;
    private static int Cedula;
    private static int Edad;
    public static Estados Estado;

    public int getCedula() {
        return Cedula;
    }

    public void setCedula(int Cedula) {
        this.Cedula = Cedula;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }
    
    
    
    
}
